package Uninter;

public class Real extends Moeda { //* extends - as classes Real/Dólar/Euro serão classes filhas da classe Moeda//*
    public Real(double valor) { //*construtor da classe real //*
        super(valor); //*super, logo, construtor da classe mão (moeda) passa o valor para a classe filha//* 
    }

    @Override
    double ConverterParaReal() {
        return valor; //*Real não precisa conversão*//
    }

    @Override
    void info() {
        System.out.printf("Real: R$%.2f%n", valor); //* mostarr as moedas salvas com seus rescpectivos símbolos*//
    }
    
    @Override
    public String toString() {
        return String.format("R$%.2f", valor); //*formata o número com 2 casas decimais e adiciona o símbolo "R$" antes.//*
    }
}