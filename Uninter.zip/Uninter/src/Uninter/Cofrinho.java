package Uninter;

import java.util.ArrayList; 

public class Cofrinho {
    ArrayList<Moeda> listaMoedas = new ArrayList<Moeda>(); //* criando uma ArrayLst para manutenção das moedas*/

    
    public void adicionar(Moeda c) {
        listaMoedas.add(c);
        System.out.println("Moeda adicionada!");
    }
    
    //* 
    public void remover(int indice) {
        if (indice >= 0 && indice < listaMoedas.size()) {
            Moeda removida = listaMoedas.remove(indice);
            System.out.println("Moeda removida: " + removida);
        } else {
            System.out.println("Índice inválido!");
        }
    }
    
    //*listagem de  todas as moedas, enumerando-as para facilitar a remoção no menu principal*//
    public void listar() {
        if (listaMoedas.isEmpty()) {
            System.out.println("O cofrinho está vazio :(");
        } else {
            System.out.println("\nMoedas no cofrinho:");
            for (int i = 0; i < listaMoedas.size(); i++) {
                System.out.print((i+1) + " - ");
                listaMoedas.get(i).info(); //* mostrará informações sobre a moeda quando for solicitada pelo usuário *//
            		}
            }
        }
    
    public double calcularTotalEmReais() {
        double total = 0;
        for (Moeda moeda : listaMoedas) {
            total += moeda.ConverterParaReal();
        }
        return total;
    }
}