package Uninter;

import java.util.Scanner; //* Scanner para registrar entradas do usuário *//

public class Principal {
    //* Classe principal como pedido no trabalho *//

    public static void main(String[] args) {
        Scanner Teclado = new Scanner(System.in);
        int opcao;

        Cofrinho Cofrinho = new Cofrinho();

        while (true) { //* Criando um loop, mantendo o menu interativo funcionando enquanto ele escolher as opções 1~4 *//
            System.out.println("--- Bem-vindo(a) ao cofrinho virtual! ---");
            System.out.println("----------------- Menu -----------------");
            System.out.println("1 - Adicionar moedas");
            System.out.println("2 - Remover moedas");
            System.out.println("3 - Lista de moedas");
            System.out.println("4 - Total Convertido para Real");
            System.out.println("5 - Encerrar");
            System.out.println("Digite uma opção:");

            opcao = Teclado.nextInt(); //* Ao escolher a opção 5 (encerrar), o loop se quebra, encerrando o código *//
            if (opcao == 5) {
                System.out.println("Fechando o cofrinho...");
                break;
            }

            switch (opcao) {
                case 1:
                    System.out.println("Escolha uma moeda:");
                    System.out.println("1 - Real");
                    System.out.println("2 - Dólar");
                    System.out.println("3 - Euro");
                    System.out.println("0 - Voltar ao menu.");

                    int tipoMoeda = Teclado.nextInt();

                    if (tipoMoeda == 0) { //* ao digitar o n° 0, o usuário será mandado de volta ao perfil //* 
                        break;
                    } else if (tipoMoeda < 1 || tipoMoeda > 3) { //* se escolher algum número que não está como opção, será avisado e continuará na página//* 
                        System.out.println("Opção inválida!");
                        continue;
                    } else {
                        System.out.println("Qual valor deseja adicionar?"); //* ao selecionar os n° de opções que existem, o código prossegue //* 
                        double valor = Teclado.nextDouble();

                        if (tipoMoeda == 1) {
                            Cofrinho.adicionar(new Real(valor));
                        } else if (tipoMoeda == 2) {
                            Cofrinho.adicionar(new Dolar(valor));
                        } else if (tipoMoeda == 3) {
                            Cofrinho.adicionar(new Euro(valor));
                        }
                    }
                    continue;

                case 2:
                    //* Mostra as moedas disponíveis no cofrinho para a pessoa saber qual moeda remover através da lista *//
                    Cofrinho.listar();

                    if (Cofrinho.listaMoedas.isEmpty()) { //* se o cofrinho estiver vazio, retorna ao menu//* 
                        continue;
                    } else {
                        System.out.print("Digite o número da moeda que deseja remover: "); 
                        int indice = Teclado.nextInt() - 1;

                        Cofrinho.remover(indice);
                    }
                    continue;
                    
                    
                case 3: 
                	while (true) { //* criando um loop  //*
                	Cofrinho.listar(); 
                	System.out.println("Para voltar ao menu clique digite 0."); //*dando a possibilidade do usuário de retornar ao menu principal ao terminar de consultar a lista de moedas //*
                	int voltar = Teclado.nextInt();
                	if (voltar == 0) {
                	break;
                	}
                		 else {		
                		}
                			System.out.println("Opção inválida! Tente novamente."); //* caso não digite o n° correto, será informado e não sairá da página até escrevê-lo//* 
                		}
                	continue;
                	
                	
                case 4:
                    if (Cofrinho.listaMoedas.isEmpty()) { 
                        System.out.println("O cofrinho está vazio :(."); //* se o cofrinho estiver vazio, aparecerá uma mensagem para o usuaário//*
                    } else {
                        double total = Cofrinho.calcularTotalEmReais(); //* caso contra´rio, printa a informação //*
                        System.out.println("Total em reais: " + total);
                    }

                    System.out.println("Para voltar ao menu, digite 0."); //*voltar ao menu principal para realizar manutenções ou fechar o programa //* 
                    int voltar = Teclado.nextInt();
                    while (voltar != 0) {
                        System.out.println("Opção inválida! Tente novamente.");
                        voltar = Teclado.nextInt();
                    }
                    break;

            }
        }
    }
}


