package Uninter;

public class Euro extends Moeda {
    public static final double TaxaConversao = 6.3;

    public Euro(double valor) {
        super(valor);
    }

    @Override
    public double ConverterParaReal() {
        return valor * TaxaConversao; 
    }

    @Override
    void info() {
        System.out.printf("Euro: €%.2f (Conversão: R$%.2f)%n", valor, ConverterParaReal());
    }
    
    @Override
    public String toString() {
        return String.format("€%.2f", valor);
    }
}