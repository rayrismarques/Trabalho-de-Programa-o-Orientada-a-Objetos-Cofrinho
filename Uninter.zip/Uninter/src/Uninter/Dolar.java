package Uninter;

public class Dolar extends Moeda {
    public static final double TaxaConversao = 5.7; 

    public Dolar(double valor) {
        super(valor);
    }

    @Override
    public double ConverterParaReal() {
        return valor * TaxaConversao;  //*operação matemática moeda * taxa de conversão para que na totalização esteja tudo em real //*
    }

    @Override
    void info() {
        System.out.printf("Dólar: US$%.2f (Conversão: R$%.2f)%n", valor, ConverterParaReal());
    }
    
    @Override
    public String toString() {
        return String.format("US$%.2f", valor);
    }
}