package Uninter;

public abstract class Moeda{ //* classe abstract, ous eja, uma classe base, servindo de modelo para as outras*//


	double valor;  //* recebendo valores double, como pedido no exercício//* 
	public Moeda(double valor) { //* valor será o atributo que irá armazenar todas as moedas, gaurdando seu valor numérico //*
		this.valor = valor;	
	}
	
	
	
	abstract double ConverterParaReal(); //* cada moeda terá sua própria taxa de conversão em suas respectivas subclasses, exceto o real
	abstract void info ();

	
	
	public static boolean IsEmpty() {   //* caso não há moedas//* 
		return false;
	}
}